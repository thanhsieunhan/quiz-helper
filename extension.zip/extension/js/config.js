// Cấu hình chung cho extension
const config = {
  API_URL: 'https://quiz.rikkei.online',
  // API_URL: 'http://localhost:8000',
};

export default config;
